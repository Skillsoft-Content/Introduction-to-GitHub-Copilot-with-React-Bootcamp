import React from 'react';

const containerStyle = {
    display: 'flex',
    justifyContent: 'space-between',
    gap: '2rem',
    padding: '2rem',
    boxSizing: 'border-box',
};

const leftColumnStyle = {
    flex: 1,
    background: '#f9f9f9',
    borderRadius: '10px',
    padding: '1.5rem',
    boxShadow: '0 1px 6px rgba(0,0,0,0.06)',
    minWidth: 0,
};

const middleColumnStyle = {
    flex: 1,
    background: '#f9f9f9',
    borderRadius: '10px',
    padding: '1.5rem',
    boxShadow: '0 1px 6px rgba(0,0,0,0.06)',
    minWidth: 0,
};

const rightColumnStyle = {
    flex: '0 0 20%',
    maxWidth: '20%',
    background: '#f9f9f9',
    borderRadius: '10px',
    padding: '1.5rem',
    boxShadow: '0 1px 6px rgba(0,0,0,0.06)',
    minWidth: 0,
};

const Home = () => (
    <div style={containerStyle}>
        <div style={leftColumnStyle}>
            <h2>Column 1</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque vitae velit ex. Mauris dapibus risus quis suscipit vulputate.</p>
        </div>
        <div style={middleColumnStyle}>
            <h2>Column 2</h2>
            <p>Morbi nec enim nunc. Phasellus bibendum turpis ut ipsum egestas, sed sollicitudin elit convallis. Cras pharetra mi tristique sapien vestibulum lobortis.</p>
        </div>
        <div style={rightColumnStyle}>
            <h2>Column 3</h2>
            <p>Ut ac ligula sapien. Suspendisse cursus faucibus finibus. Integer tempus ligula sem, id feugiat quam egestas at. Pellentesque habitant morbi tristique senectus.</p>
        </div>
    </div>
);

export default Home;