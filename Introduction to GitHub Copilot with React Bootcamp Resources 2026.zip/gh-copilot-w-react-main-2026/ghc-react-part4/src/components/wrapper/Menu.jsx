import React from 'react';
import './wrapper.css';

const links = [
    { href: '/', label: 'Home' },
    { href: '/about-us', label: 'About Us' },
    { href: '/contact-us', label: 'Contact Us' },
    { href: '/admin', label: 'Admin' },
];

const Menu = () => {
    const [hovered, setHovered] = React.useState(null);

    return (
        <nav className="menu">
            {links.map((link, idx) => (
                <a
                    key={link.href}
                    href={link.href}
                    className={`menu-link${hovered === idx ? ' menu-link-hover' : ''}`}
                    onMouseEnter={() => setHovered(idx)}
                    onMouseLeave={() => setHovered(null)}
                >
                    {link.label}
                </a>
            ))}
        </nav>
    );
};

export default Menu;