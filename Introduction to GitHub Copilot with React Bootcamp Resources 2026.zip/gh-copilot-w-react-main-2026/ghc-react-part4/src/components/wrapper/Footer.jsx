import React from 'react';
import './wrapper.css';

const Footer = () => (
    <footer className="footer">
        &copy; {new Date().getFullYear()} Animal Explorer. All rights reserved.
    </footer>
);

export default Footer;