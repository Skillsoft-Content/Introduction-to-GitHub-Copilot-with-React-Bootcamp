import React from 'react';
import './wrapper.css';

const Header = () => (
    <header className="header">
        <img
            src="https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=200&q=80"
            alt="Animals"
            className="header-img"
            loading="lazy"
        />
        <h1 className="header-title">Welcome to Animal Explorer</h1>
    </header>
);

export default Header;