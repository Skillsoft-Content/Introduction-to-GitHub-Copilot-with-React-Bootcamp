import React from 'react';
import PageWrapper from './components/wrapper/PageWrapper';
import Home from './components/Home';

const App = () => {
    return (
        <PageWrapper>
            <Home />
        </PageWrapper>
    );
};

export default App;