import React from 'react';

const ExampleComponent = () => {
    return (
        <div>
            <h1>Hello from ExampleComponent!</h1>
        </div>
    );
};

export default ExampleComponent;