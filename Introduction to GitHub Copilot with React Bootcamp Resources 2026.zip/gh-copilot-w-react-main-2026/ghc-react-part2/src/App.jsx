import React from 'react';
import ExampleComponent from './components/ExampleComponent';

const App = () => {
    return (
        <div>
            <h1>Welcome to My React 19 Project</h1>
            <ExampleComponent />
        </div>
    );
};

export default App;