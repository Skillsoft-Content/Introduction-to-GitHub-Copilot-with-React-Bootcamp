import React from 'react';

const menuStyle = {
    width: '100%',
    background: '#e0f7fa',
    display: 'flex',
    justifyContent: 'flex-start',
    padding: '0.5rem 2rem',
    boxSizing: 'border-box',
    boxShadow: '0 1px 4px rgba(0,0,0,0.05)',
    gap: '2rem',
};

const linkStyle = {
    color: '#2d3a3a',
    textDecoration: 'none',
    fontWeight: 600,
    fontSize: '1.1rem',
    padding: '0.3rem 0.7rem',
    borderRadius: '6px',
    transition: 'background 0.2s',
};

const linkHoverStyle = {
    background: '#b2ebf2',
};

const links = [
    { href: '/', label: 'Home' },
    { href: '/about-us', label: 'About Us' },
    { href: '/contact-us', label: 'Contact Us' },
    { href: '/admin', label: 'Admin' },
];

const Menu = () => {
    const [hovered, setHovered] = React.useState(null);

    return (
        <nav style={menuStyle}>
            {links.map((link, idx) => (
                <a
                    key={link.href}
                    href={link.href}
                    style={{
                        ...linkStyle,
                        ...(hovered === idx ? linkHoverStyle : {}),
                    }}
                    onMouseEnter={() => setHovered(idx)}
                    onMouseLeave={() => setHovered(null)}
                >
                    {link.label}
                </a>
            ))}
        </nav>
    );
};

export default Menu;