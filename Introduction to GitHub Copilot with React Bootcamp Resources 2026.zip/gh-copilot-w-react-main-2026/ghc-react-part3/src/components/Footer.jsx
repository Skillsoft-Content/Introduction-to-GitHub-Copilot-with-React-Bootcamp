import React from 'react';

const footerStyle = {
    width: '100%',
    background: '#e0f7fa',
    textAlign: 'center',
    padding: '1rem 0',
    marginTop: '2rem',
    fontSize: '1rem',
    color: '#2d3a3a',
    boxShadow: '0 -1px 4px rgba(0,0,0,0.04)',
};

const Footer = () => (
    <footer style={footerStyle}>
        &copy; {new Date().getFullYear()} Animal Explorer. All rights reserved.
    </footer>
);

export default Footer;