import React from 'react';

const headerStyle = {
    height: '20vh',
    minHeight: '120px',
    width: '100%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-start',
    background: 'linear-gradient(90deg, #e0f7fa 0%, #fffde4 100%)',
    padding: '0 2rem',
    boxSizing: 'border-box',
    boxShadow: '0 2px 8px rgba(0,0,0,0.07)',
};

const imgStyle = {
    height: '80%',
    maxHeight: '90px',
    marginRight: '1.5rem',
    borderRadius: '12px',
    objectFit: 'cover',
    boxShadow: '0 2px 8px rgba(0,0,0,0.10)',
};

const titleStyle = {
    fontSize: '2.2rem',
    fontWeight: 700,
    color: '#2d3a3a',
    letterSpacing: '1px',
};

const Header = () => (
    <header style={headerStyle}>
        <img
            src="https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=200&q=80"
            alt="Animals"
            style={imgStyle}
            loading="lazy"
        />
        <h1 style={titleStyle}>Welcome to Animal Explorer</h1>
    </header>
);

export default Header;