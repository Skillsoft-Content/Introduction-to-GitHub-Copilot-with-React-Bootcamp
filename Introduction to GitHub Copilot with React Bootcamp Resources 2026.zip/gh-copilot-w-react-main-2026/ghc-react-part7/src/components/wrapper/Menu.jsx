import React from 'react';
import './wrapper.css';

const links = [
    { href: '/', label: 'Home' },
    { href: '/about-us', label: 'About Us' },
    { href: '/contact-us', label: 'Contact Us' },
    { href: '/admin', label: 'Admin' },
    { href: '/learn-stuff', label: 'Learn Stuff' }, // Add this line
];

const Menu = ({ onNavigate }) => {
    const [hovered, setHovered] = React.useState(null);

    const handleClick = (e, href) => {
        if (onNavigate) {
            e.preventDefault();
            onNavigate(href);
        }
    };

    return (
        <nav className="menu">
            {links.map((link, idx) => (
                <a
                    key={link.href}
                    href={link.href}
                    className={`menu-link${hovered === idx ? ' menu-link-hover' : ''}`}
                    onMouseEnter={() => setHovered(idx)}
                    onMouseLeave={() => setHovered(null)}
                    onClick={e => handleClick(e, link.href)}
                >
                    {link.label}
                </a>
            ))}
        </nav>
    );
};

export default Menu;