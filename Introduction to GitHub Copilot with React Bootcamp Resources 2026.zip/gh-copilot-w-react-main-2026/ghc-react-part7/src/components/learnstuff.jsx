import React from 'react';

// This is a simple functional component that receives props.
// "props" is an object containing all the properties passed to this component.
function Greeting(props) {
    // You can access individual props using dot notation, e.g., props.name
    return (
        <div>
            {/* Display the name prop */}
            <h2>Hello, {props.name}!</h2>
            {/* Display the message prop */}
            <p>{props.message}</p>
        </div>
    );
}

// Example parent component that uses the Greeting component
export default function LearnPropsExample() {
    // Here we pass two props: name and message
    return (
        <div>
            <h1>Learning about Props in React</h1>
            {/* 
                The Greeting component receives "name" and "message" as props.
                These values are accessible inside Greeting via the "props" parameter.
            */}
            <Greeting name="Axle Barr" message="Welcome to learning React props!" />
        </div>
    );
}

/*
    Explanation:
    - "Props" (short for "properties") are how you pass data from a parent component to a child component in React.
    - The child component receives props as a single object argument.
    - Props are read-only: the child cannot change the props it receives.
    - You can pass any type of data as props: strings, numbers, objects, functions, etc.
    */