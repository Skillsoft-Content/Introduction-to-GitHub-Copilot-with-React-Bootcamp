import React, { useState } from 'react';
import PageWrapper from './components/wrapper/PageWrapper';
import Home from './components/Home';
import ContactUs from './components/ContactUs';

const App = () => {
    const [route, setRoute] = useState(window.location.pathname);

    React.useEffect(() => {
        const handlePopState = () => setRoute(window.location.pathname);
        window.addEventListener('popstate', handlePopState);
        return () => window.removeEventListener('popstate', handlePopState);
    }, []);

    const handleNavigate = (path) => {
        window.history.pushState({}, '', path);
        setRoute(path);
    };

    return (
        <PageWrapper onNavigate={handleNavigate}>
            {route === '/contact-us' ? <ContactUs /> : <Home />}
        </PageWrapper>
    );
};

export default App;