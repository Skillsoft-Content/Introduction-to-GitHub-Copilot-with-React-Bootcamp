import React, { useState } from 'react';
import './styles.css';

const initialState = { username: '', email: '', message: '', captcha: '' };

function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

const ContactUs = () => {
    const [form, setForm] = useState(initialState);
    const [errors, setErrors] = useState({});
    const [captchaNums] = useState({
        a: getRandomInt(1, 10),
        b: getRandomInt(1, 10)
    });

    const validate = () => {
        const errs = {};
        if (!form.username.trim()) errs.username = 'Username is required';
        if (!form.email.trim()) {
            errs.email = 'Email is required';
        } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/.test(form.email)) {
            errs.email = 'Invalid email address';
        }
        if (!form.message.trim()) errs.message = 'Message is required';
        if (parseInt(form.captcha, 10) !== captchaNums.a + captchaNums.b) {
            errs.captcha = 'Incorrect answer to the human check';
        }
        setErrors(errs);
        return Object.keys(errs).length === 0;
    };

    const handleChange = e => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    const handleSubmit = e => {
        e.preventDefault();
        validate();
    };

    return (
        <div className="contact-container">
            <h2>Contact Us</h2>
            <form className="contact-form" onSubmit={handleSubmit} noValidate>
                <div className="form-group">
                    <label htmlFor="username">Username:</label>
                    <input
                        type="text"
                        id="username"
                        name="username"
                        value={form.username}
                        onChange={handleChange}
                        className={errors.username ? 'input-error' : ''}
                    />
                    {errors.username && <span className="error">{errors.username}</span>}
                </div>
                <div className="form-group">
                    <label htmlFor="email">Email:</label>
                    <input
                        type="email"
                        id="email"
                        name="email"
                        value={form.email}
                        onChange={handleChange}
                        className={errors.email ? 'input-error' : ''}
                    />
                    {errors.email && <span className="error">{errors.email}</span>}
                </div>
                <div className="form-group">
                    <label htmlFor="message">Message:</label>
                    <textarea
                        id="message"
                        name="message"
                        value={form.message}
                        onChange={handleChange}
                        className={errors.message ? 'input-error' : ''}
                        rows={5}
                    />
                    {errors.message && <span className="error">{errors.message}</span>}
                </div>
                <div className="form-group">
                    <label htmlFor="captcha">
                        Human check: What is {captchaNums.a} + {captchaNums.b}?
                    </label>
                    <input
                        type="text"
                        id="captcha"
                        name="captcha"
                        value={form.captcha}
                        onChange={handleChange}
                        className={errors.captcha ? 'input-error' : ''}
                        autoComplete="off"
                    />
                    {errors.captcha && <span className="error">{errors.captcha}</span>}
                </div>
                <button type="submit">Send</button>
            </form>
        </div>
    );
};

export default ContactUs;