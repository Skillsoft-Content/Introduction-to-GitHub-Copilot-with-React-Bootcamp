import React from 'react';
import './styles.css';

const Home = () => (
    <div className="home-container">
        <div className="home-column home-left">
            <h2>Column 1</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque vitae velit ex. Mauris dapibus risus quis suscipit vulputate.</p>
        </div>
        <div className="home-column home-middle">
            <h2>Column 2</h2>
            <p>Morbi nec enim nunc. Phasellus bibendum turpis ut ipsum egestas, sed sollicitudin elit convallis. Cras pharetra mi tristique sapien vestibulum lobortis.</p>
        </div>
        <div className="home-column home-right">
            <h2>Column 3</h2>
            <p>Ut ac ligula sapien. Suspendisse cursus faucibus finibus. Integer tempus ligula sem, id feugiat quam egestas at. Pellentesque habitant morbi tristique senectus.</p>
        </div>
    </div>
);

export default Home;